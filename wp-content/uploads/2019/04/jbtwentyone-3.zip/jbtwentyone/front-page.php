<?php
/*
Template Name: Custom Homepage
 */

get_header();
?>
<!-- page title -->
<!-- Main Page Content -->
<!-- page featured image -->
<!-- two custom fields -->
<!-- lastest 5 posts previews with links -->

<?php get_footer(); ?>

