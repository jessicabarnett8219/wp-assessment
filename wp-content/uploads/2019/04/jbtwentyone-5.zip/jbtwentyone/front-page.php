<?php
/*
Template Name: Custom Homepage
 */

get_header();
?>
<section id="primary" class="content-area">
		<main id="main" class="site-main">
<!-- page title -->
        <h1><?php the_title(); ?></h1>
       <?php get_field( 'name' ); ?>
       <?php get_field( 'date_visited' ); ?>
<!-- Main Page Content -->
<!-- page featured image -->
        </main>
        </section>
<!-- two custom fields -->
<!-- lastest 5 posts previews with links -->

<?php get_footer(); ?>

