<?php
/**
 * The template for displaying the footer.
 */
?>

</div><!-- .site-wrapper -->

<footer class="site-footer">
	<span>&copy; <?php echo date( 'M' ); ?> All Rights Reserved.
</footer>

<?php wp_footer(); ?>
</body>
</html>
